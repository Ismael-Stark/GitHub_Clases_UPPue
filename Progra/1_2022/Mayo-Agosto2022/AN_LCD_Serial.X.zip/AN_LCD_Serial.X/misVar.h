  const float mv=(3.3/1023);
float volt, temperatura;
uint8_t rx, buffer[50], contador = 0;
    uint16_t adc=0;
    int8_t  high_byte, tecla;
    uint8_t low_byte;
    bool encontrado=0;